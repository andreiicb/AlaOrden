package com.example.comandas.data.local

import com.example.comandas.R

class FoodProvider {

    companion object{

        val FoodList = listOf<Food>(
            Food(
                "Hamburguesa",
                "Una jugosa hamburguesa de 225 gr. de carne Angus, sazonada con nuestra mezcla de especias y servida con lechuga, tomate, cebolla roja, pepinillos y mayonesa en un pan artesanal.",
                120.00,
                R.drawable.hamburguesa
            ),
            Food(
                "Pizza",
                "Se trata de un pan plano horneado, habitualmente de forma redonda, elaborado con harina de trigo, sal, agua y levadura, cubierto con salsa de tomate y queso.",
                190.00,
                R.drawable.pizza
            ),
            Food(
                "Hot Dogs",
                "3 panecillos largos llenos con una salchicha de Frankfurt, que se consume caliente, y untado de mostaza ligeramente dulce.",
                100.00,
                R.drawable.hotdogs
            ),
            Food(
                "Nachos",
                "Especialidad del norte de México y sur de los Estados Unidos consistente en pedazos triangulares de tortilla de maíz, fritos y bañados con queso amarillo derretido. Fuera de México es usual consumirlos con diversas salsas (guacamole o mayonesa), queso, frijoles o con carne asada.",
                150.00,
                R.drawable.nachos
            ),
            Food(
                "Quesadillas",
                "Antojito que consiste en una tortilla de masa de maíz doblada a la mitad en forma de media luna, rellena con queso fresco para derretir o algún otro guiso (tinga, papa, hongos, picadillo, cuitlacoche, rajas, etc.) y cocida en comal o frita.",
                120.00,
                R.drawable.quesadillas
            )
        )

    }
}