package com.example.comandas.ui.fragments

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import android.widget.Toolbar
import androidx.fragment.app.setFragmentResultListener
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.navigation.navArgument
import androidx.navigation.navDeepLink
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.comandas.data.adapter.FoodAdapter
import com.example.comandas.data.adapter.FoodViewHolder
import com.example.comandas.data.local.Food
import com.example.comandas.data.local.FoodProvider
import com.example.comandas.data.local.FoodProvider.Companion.FoodList
import com.example.comandas.databinding.FragmentSecondBinding
import com.example.comandas.ui.fragments.details.FoodDetailsFragment
import java.lang.Error

class SecondFragment : Fragment() {

    private var _binding: FragmentSecondBinding? = null   //BINDING - LLAMAR ELEMENTOS XML MAS FACIL
    private val binding get() = _binding!!

    val args: SecondFragmentArgs by navArgs()  //pasar datos - primero declarar argumentos en el graph
    private var name: String? = ""

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentSecondBinding.inflate(inflater, container, false)
        return binding.root //BINDING CONTINUCACIÓN, NOMAS CAMBIA EL FRAGMENT

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        Toolbar = binding.myToolbar


        initRecyclerViewer() //llamar a la fun del recycler

        name = args.nombre
        val texto = "Hola $name, este es el fragment2"
        //Toast.makeText(activity, texto, Toast.LENGTH_SHORT).show()

    }

    private fun initRecyclerViewer() {  //funcion de iniciar el recycler
        val manager = LinearLayoutManager(requireContext())
        binding.rvMenu.layoutManager = manager
        binding.rvMenu.adapter =
            FoodAdapter(FoodProvider.FoodList) { food ->
                onItemSelected(food)
            }

    }

    private fun onItemSelected(food: Food) { //food es el item del rv
        val foodNameDetails = food.FoodName
        val foodPriceDetails = food.Price //arguments del fragment al que seran enviados
        val foodImgDetails = food.photo
        val foodOverviewDetails = food.Overview
        val uri = Uri.parse("comandas://details/$foodNameDetails/$foodPriceDetails/$foodImgDetails/$foodOverviewDetails")
        findNavController().navigate(uri) //asignar los arguments del deep link en el nav graph

    }
}
