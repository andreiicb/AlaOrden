package com.example.comandas.data.local

data class Food(
    val FoodName: String,
    val Overview: String,
    val Price: Double,
    val photo: Int
)